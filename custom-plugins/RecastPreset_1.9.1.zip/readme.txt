MA2 Recast Preset
version 1.9.1
Last update May 5, 2024
Developed by Jeremy Dufeux - Carrot Industries
https://carrot-industries.com
contact: contact@carrot-industries.com

Thank you for purchasing this plugin

This is the content of the archive you downloaded:
    - readme.txt
    - Recast Preset.lua
    - Recast Preset.xml
    
************************ Installation *******************************

To install the plugin in your show:
    - put those files in a USB stick in the gma2/plugins/ folder:
        * Recast Preset.lua
        * Recast Preset.xml
    - load the USB stick in your show, import the plugin
    - to enable the plugin simply run this command, this is a safety to protect plugin from theft:
        SetVar $CIRP = CIBUOYLQVATMRP42

********************** Using the plugin *****************************

How to do: 
    - Make a backup
    - Run the plugin
    - If you have a running session the plugin will ask to end the session
    - If you have an active selection, the plugin will ask you if you want to recast just for the selection or all fixtures
    - It will ask you if you want to use the plugin in cue only mode:
        by select "Ok", it will use cue only mode, so the values will not be tracked if original values are absent
        if you select "Cancel", it will not use cue only mode, so the values will be tracked
    - en finally it will ask you the preset number, you can simply enter one preset, a range of presets, and use add or minus operators
    - at the end th plugin will show you how many cues was updated and eventually ask you to restart the session!

*************************** Notes **********************************

Note that: 
    - For an enhanced result, delete all Executor pages you don't need 
    - The plugin can take a while to execute depending on your sequences amount
    - If the plugin seems to work not properly you can increase the config.telnetTimeout value, it varies from one show to another, up to 2s on some shows
    - You can customize the config.useSelection to perform the recast with only the selected fixtures
    - You can recast multiple presets with by using the config.presetList field

*************************** Legal **********************************

The entire content and modifications of this code are protected under copyright by Carrot Industries. 
They cannot be utilized, either in whole or in part, without obtaining written permission from Jérémy Dufeux and acknowledging the source. 
This plugin is exclusively authorized for use by individuals who have acquired it directly from carrot-industries.com . 
Please show respect by refraining from unauthorized use and by appropriately attributing the work to its creators.

The use and modification of this plugin is at your own risk, be sure to do all backups you need before use it.
Carrot Industries declines all responsibility in the event of loss of data, system failures, or any other harm that may result from the use of the plugin
We will not be held responsible for any direct or indirect consequences related to the use of our plugins.